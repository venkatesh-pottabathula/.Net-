﻿namespace DotNetCoreDemo.Models
{
    public class DataAccessLayer
    {

    }
}
