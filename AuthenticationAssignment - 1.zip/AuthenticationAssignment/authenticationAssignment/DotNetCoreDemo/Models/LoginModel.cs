﻿namespace DotNetCoreDemo.Models
{
    public class LoginModel
    {
        public string username { get; set; }
        public string possword { get; set; }
    }
}
