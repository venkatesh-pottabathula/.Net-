﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DotNetCoreDemo.Models.DB
{
    public partial class Student
    {
        public int? Sno { get; set; }
        public string Sname { get; set; }
        public int? Age { get; set; }
    }
}
